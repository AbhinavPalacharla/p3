#ifndef UTILS_H_
#define UTILS_H_

#include <string.h>

char *strip(char *str);

#endif